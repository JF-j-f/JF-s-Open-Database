class Test01 {

    public static void main(String[] args) {
        System.out.println("hello, world!");
    }
}