from random import sample

from django.shortcuts import render


def show_index(request):
    fruits = [
        'Apple', 'Orange', 'Pitaya', 'Durian', 'Waxberry', 'Blueberry',
        'Grape', 'Peach', 'Pear', 'Banana', 'Watermelon', 'Mango'
    ]
    return render(request, 'index.html', {'fruits': sample(fruits, 3)})
