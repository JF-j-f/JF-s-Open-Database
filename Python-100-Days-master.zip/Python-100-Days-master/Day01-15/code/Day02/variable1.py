"""
使用变量保存数据并进行操作

Version: 0.1
Author: 骆昊
Date: 2018-02-27
"""

a = 321
b = 123
print(a + b)
print(a - b)
print(a * b)
print(a / b)
print(a // b)
print(a % b)
print(a ** b)
