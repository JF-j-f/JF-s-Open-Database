print(sum(range(1, 101)))
