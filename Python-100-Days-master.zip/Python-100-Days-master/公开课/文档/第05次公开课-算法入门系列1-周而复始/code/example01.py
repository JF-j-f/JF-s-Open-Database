nums = []
for i in range(100000):
    nums.append(i)
nums.reverse()
print(nums)
